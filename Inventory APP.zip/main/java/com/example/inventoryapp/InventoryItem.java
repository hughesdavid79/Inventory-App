package com.example.inventoryapp;

/**
 * Class representing an item in the inventory.
 */
public class InventoryItem {
    private String name; // The name of the inventory item.
    private int quantity; // The quantity of the inventory item in stock.

    /**
     * Constructor to create a new InventoryItem.
     * @param name The name of the item.
     * @param quantity The initial quantity of the item.
     */
    public InventoryItem(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    /**
     * Gets the name of the inventory item.
     * @return A string representing the item's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the inventory item.
     * @param name A string containing the new name of the item.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the current quantity of the inventory item.
     * @return An integer representing the current quantity of the item.
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Sets the quantity of the inventory item.
     * @param quantity The new quantity to set for the item.
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
