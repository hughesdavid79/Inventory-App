package com.example.inventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.content.ContextCompat;

/**
 * Utility class to handle sending SMS notifications.
 */
public class NotificationSender {

    /**
     * Sends an SMS notification to a specified phone number if the permission is granted.
     * @param context The context used to access application-specific resources.
     * @param message The message to be sent as an SMS notification.
     */
    public static void sendSmsNotification(Context context, String message) {
        // Retrieve phone number from SharedPreferences.
        SharedPreferences prefs = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        String phoneNumber = prefs.getString("PhoneNumber", "");

        // Check if the phone number is available and SMS permissions are granted.
        if (!phoneNumber.isEmpty() && ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            // Get the default instance of SmsManager and send the text message.
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        } else {
            // Log an error or notify the user in case the phone number is empty or permission is not granted.
            if (phoneNumber.isEmpty()) {
                Log.e("NotificationSender", "Phone number is empty. Cannot send SMS notification.");
            } else {
                Log.e("NotificationSender", "Permission to send SMS is not granted.");
            }
        }
    }
}
