package com.example.inventoryapp;

import java.util.ArrayList;
import java.util.List;

// Class to manage the inventory data for the application.
public class InventoryData {
    private static List<InventoryItem> inventoryItems = new ArrayList<>(); // Static list to store inventory items.

    /**
     * Retrieves all inventory items.
     * @return a list of all current inventory items.
     */
    public static List<InventoryItem> getInventoryItems() {
        return inventoryItems;
    }

    /**
     * Adds a new inventory item to the list.
     * @param item the InventoryItem to add.
     */
    public static void addInventoryItem(InventoryItem item) {
        inventoryItems.add(item);
    }

    /**
     * Removes an existing inventory item from the list.
     * @param item the InventoryItem to remove.
     */
    public static void removeInventoryItem(InventoryItem item) {
        inventoryItems.remove(item);
    }

    /**
     * Updates the quantity of an existing inventory item.
     * @param item the InventoryItem to update.
     * @param quantity the new quantity to set.
     */
    public static void updateInventoryItem(InventoryItem item, int quantity) {
        item.setQuantity(quantity);
    }

    /**
     * Updates the entire list of inventory items with a new list.
     * This method first clears the existing list and then adds all elements from the updated list.
     * @param updatedList the new list of inventory items to replace the current list.
     */
    public static void updateInventoryList(List<InventoryItem> updatedList) {
        inventoryItems.clear();
        inventoryItems.addAll(updatedList);
    }
}
