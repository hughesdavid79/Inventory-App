package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity class handles user login, registration, and SMS permission requests.
 */
public class MainActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1; // Permission request code for SMS.

    private EditText usernameEditText, passwordEditText; // User input fields for username and password.
    private Button loginButton, registerButton, requestPermissionButton; // Buttons for user interaction.
    private TextView permissionStatusView; // Displays the status of SMS permission.

    private List<InventoryItem> inventoryItems; // List to hold inventory data.
    private Gson gson; // Gson object for JSON serialization.
    private DatabaseHelper databaseHelper; // Database helper for user authentication.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gson = new Gson();
        databaseHelper = new DatabaseHelper(this);

        // Initialize UI components.
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);
        requestPermissionButton = findViewById(R.id.requestPermissionButton);
        permissionStatusView = findViewById(R.id.permissionStatusTextView);

        inventoryItems = loadInventoryFromPrefs(); // Load inventory from preferences.

        // Setup button listeners.
        loginButton.setOnClickListener(v -> login());
        registerButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, RegistrationActivity.class)));
        requestPermissionButton.setOnClickListener(v -> requestSMSPermission());

        // Initialize inventory data if necessary.
        if (inventoryItems == null || inventoryItems.isEmpty()) {
            initializeInventoryData();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionStatus(); // Update permission status on UI resume.
    }

    private void login() {
        // Handle user login.
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Check user credentials and navigate accordingly.
        if (databaseHelper.checkUser(username, password)) {
            Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this, InventoryActivity.class));
        } else {
            Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestSMSPermission() {
        // Request SMS permission if not already granted.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
        } else {
            Toast.makeText(this, "SMS permission is already granted.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_PERMISSIONS_REQUEST_SEND_SMS) {
            updatePermissionStatus(); // Update SMS permission status after user response.
        }
    }

    private void updatePermissionStatus() {
        // Update the UI with the current permission status.
        boolean hasSMSPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        permissionStatusView.setText("Permission Granted: " + (hasSMSPermission ? "True" : "False"));
    }

    private List<InventoryItem> loadInventoryFromPrefs() {
        // Load inventory items from SharedPreferences.
        SharedPreferences prefs = getSharedPreferences("inventory_prefs", MODE_PRIVATE);
        String json = prefs.getString("inventory", null);
        Type type = new TypeToken<List<InventoryItem>>() {}.getType();
        return gson.fromJson(json, type);
    }

    private void initializeInventoryData() {
        // Initialize inventory data and store it in SharedPreferences.
        inventoryItems = new ArrayList<>();
        inventoryItems.add(new InventoryItem("Item 1", 10));
        inventoryItems.add(new InventoryItem("Item 2", 20));
        inventoryItems.add(new InventoryItem("Item 3", 30));

        SharedPreferences prefs = getSharedPreferences("inventory_prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        String json = gson.toJson(inventoryItems);
        editor.putString("inventory", json);
        editor.apply();
    }
}
