package com.example.inventoryapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.List;

// Adapter class for managing inventory items in a RecyclerView.
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private List<InventoryItem> inventoryData; // List of inventory items to display.
    private LayoutInflater inflater; // LayoutInflater to inflate views.
    private SharedPreferences sharedPreferences; // SharedPreferences to store inventory data.
    private Gson gson; // Gson object for serializing inventory data to JSON.
    private Runnable inventoryStatusUpdater; // Runnable to update inventory status in the UI.

    // Constructor initializing the adapter with context and inventory data.
    public InventoryAdapter(Context context, List<InventoryItem> inventoryData, Runnable inventoryStatusUpdater) {
        this.inflater = LayoutInflater.from(context);
        this.inventoryData = inventoryData;
        this.sharedPreferences = context.getSharedPreferences("inventory_prefs", Context.MODE_PRIVATE);
        this.gson = new Gson();
        this.inventoryStatusUpdater = inventoryStatusUpdater;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the custom layout for each item in the RecyclerView.
        View view = inflater.inflate(R.layout.grid_item_layout, parent, false);
        return new ViewHolder(view, this);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Bind data to the ViewHolder.
        InventoryItem item = inventoryData.get(position);
        holder.textViewItemData.setText(item.getName());
        holder.textViewQuantity.setText(String.valueOf(item.getQuantity()));

        // Set listeners for incrementing, decrementing, and removing inventory items.
        holder.decreaseQuantityButton.setOnClickListener(v -> {
            if (item.getQuantity() > 0) {
                item.setQuantity(item.getQuantity() - 1);
                saveInventoryToPrefs();
                notifyDataSetChanged();
                inventoryStatusUpdater.run();
            }
        });

        holder.increaseQuantityButton.setOnClickListener(v -> {
            item.setQuantity(item.getQuantity() + 1);
            saveInventoryToPrefs();
            notifyDataSetChanged();
            inventoryStatusUpdater.run();
        });

        holder.removeButton.setOnClickListener(v -> {
            int adapterPosition = holder.getAdapterPosition();
            if (adapterPosition != RecyclerView.NO_POSITION) {
                inventoryData.remove(adapterPosition);
                saveInventoryToPrefs();
                notifyItemRemoved(adapterPosition);
                inventoryStatusUpdater.run();
            }
        });
    }

    @Override
    public int getItemCount() {
        return inventoryData.size(); // Return the total number of items in the data set.
    }

    private void saveInventoryToPrefs() {
        // Save the current state of the inventory to SharedPreferences.
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String json = gson.toJson(inventoryData);
        editor.putString("inventory", json);
        editor.apply();
    }

    // ViewHolder class provides references to the views for each data item.
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewItemData, textViewQuantity;
        Button decreaseQuantityButton, increaseQuantityButton, removeButton;
        InventoryAdapter adapter; // Reference to the adapter to access its methods.

        public ViewHolder(View itemView, InventoryAdapter adapter) {
            super(itemView);
            textViewItemData = itemView.findViewById(R.id.itemNameTextView);
            textViewQuantity = itemView.findViewById(R.id.itemQuantityTextView);
            decreaseQuantityButton = itemView.findViewById(R.id.decreaseQuantityButton);
            increaseQuantityButton = itemView.findViewById(R.id.increaseQuantityButton);
            removeButton = itemView.findViewById(R.id.removeButton);
            this.adapter = adapter;
        }
    }
}
