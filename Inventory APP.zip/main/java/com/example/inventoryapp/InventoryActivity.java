package com.example.inventoryapp;

import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    private RecyclerView inventoryRecyclerView; // RecyclerView for displaying inventory items.
    private InventoryAdapter inventoryAdapter; // Adapter for the RecyclerView.
    private List<InventoryItem> inventoryItems; // List to hold inventory items.
    private TextView notificationTextView; // TextView for displaying inventory status.
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1; // Permission request code for sending SMS.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Setup RecyclerView and its layout manager.
        inventoryRecyclerView = findViewById(R.id.inventoryRecyclerView);
        notificationTextView = findViewById(R.id.notificationTextView);
        inventoryRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // Load inventory items from SharedPreferences and set up the adapter.
        inventoryItems = loadInventoryFromPrefs();
        inventoryAdapter = new InventoryAdapter(this, inventoryItems, this::updateInventoryStatus);
        inventoryRecyclerView.setAdapter(inventoryAdapter);

        // Set up the button for adding new items.
        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(view -> showAddItemDialog());

        // Update the visual representation of inventory status.
        updateInventoryStatus();
    }

    private void showAddItemDialog() {
        // Build and display a custom dialog for adding new inventory items.
        AlertDialog.Builder builder = new AlertDialog.Builder(InventoryActivity.this);
        builder.setTitle("Add New Item");

        // Inflate the custom layout for the dialog.
        View customDialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        EditText itemNameInput = customDialogView.findViewById(R.id.itemNameInput);
        EditText itemQuantityInput = customDialogView.findViewById(R.id.itemQuantityInput);

        builder.setView(customDialogView);

        // Setup dialog buttons and handle their actions.
        builder.setPositiveButton("Add", (dialog, which) -> {
            String itemName = itemNameInput.getText().toString().trim();
            int itemQuantity;
            try {
                itemQuantity = Integer.parseInt(itemQuantityInput.getText().toString().trim());
            } catch (NumberFormatException e) {
                Toast.makeText(InventoryActivity.this, "Invalid quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add the new item to the list, update adapter, and save to SharedPreferences.
            inventoryItems.add(new InventoryItem(itemName, itemQuantity));
            inventoryAdapter.notifyDataSetChanged();
            saveInventoryToPrefs();
            updateInventoryStatus();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    public void updateInventoryStatus() {
        // Check inventory status and update TextView accordingly.
        boolean isLowStock = false;
        for (InventoryItem item : inventoryItems) {
            if (item.getQuantity() < 5) {
                isLowStock = true;
                break;
            }
        }

        SharedPreferences prefs = getSharedPreferences("inventory_prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        // Display and save the current inventory status.
        if (isLowStock) {
            notificationTextView.setText("Low Stock");
            editor.putString("inventoryStatus", "Low Stock");
        } else {
            notificationTextView.setText("Inventory Sufficient");
            editor.putString("inventoryStatus", "Inventory Sufficient");
        }
        editor.apply();
    }

    private void saveInventoryToPrefs() {
        // Save the current inventory list to SharedPreferences.
        SharedPreferences sharedPreferences = getSharedPreferences("inventory_prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(inventoryItems);
        editor.putString("inventory", json);
        editor.apply();
    }

    public void checkAndNotifyLowInventory() {
        // Check for low inventory and send notification if necessary.
        boolean isLowStock = false;
        StringBuilder lowStockItems = new StringBuilder();

        for (InventoryItem item : inventoryItems) {
            if (item.getQuantity() < 5) { // Assuming 5 is the threshold for low stock.
                isLowStock = true;
                lowStockItems.append(item.getName()).append(" is low in stock. ");
            }
        }

        if (isLowStock) {
            sendLowStockNotification(lowStockItems.toString());
        }
    }

    private void sendLowStockNotification(String message) {
        // Send an SMS notification for low stock items.
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String phoneNumber = prefs.getString("PhoneNumber", "");

        if (!phoneNumber.isEmpty()) {
            // Check SMS permission and send an SMS if permitted.
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "Low stock SMS notification sent.", Toast.LENGTH_LONG).show();
            } else {
                // Request SMS sending permission if not already granted.
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        } else {
            Toast.makeText(this, "No phone number set for notifications.", Toast.LENGTH_LONG).show();
        }
    }

    private List<InventoryItem> loadInventoryFromPrefs() {
        // Load the inventory list from SharedPreferences.
        SharedPreferences sharedPreferences = getSharedPreferences("inventory_prefs", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("inventory", null);
        Log.d("InventoryActivity", "JSON retrieved from SharedPreferences: " + json);

        if (json != null) {
            Type type = new TypeToken<List<InventoryItem>>() {}.getType();
            return gson.fromJson(json, type);
        } else {
            Log.e("InventoryActivity", "No inventory data found in SharedPreferences.");
            return new ArrayList<>();
        }
    }
}
