package com.example.inventoryapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// DatabaseHelper class to manage database creation and version management.
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version constants.
    private static final String DATABASE_NAME = "UserDB";
    private static final int DATABASE_VERSION = 1;
    // Table and column name constants.
    private static final String TABLE_NAME = "users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Constructor that configures the DB name and version.
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creates the database table for the first time when the database is created.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_USERNAME + " TEXT PRIMARY KEY," +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createTableQuery);
    }

    // Updates the database structure if a new version is detected.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME); // Removes old table structure.
        onCreate(db); // Recreates the new table structure.
    }

    // Adds a new user to the database if the username does not already exist.
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});
        if (cursor.getCount() == 0) { // Checks if the user already exists.
            cursor.close();
            String insertQuery = "INSERT INTO " + TABLE_NAME + " (" + COLUMN_USERNAME + ", " + COLUMN_PASSWORD + ") VALUES (?, ?)";
            db.execSQL(insertQuery, new String[]{username, password}); // Inserts new user data.
            return true;
        }
        cursor.close();
        return false; // Returns false if user exists.
    }

    // Checks if the user exists in the database with the given username and password.
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});
        boolean result = cursor.getCount() > 0; // Returns true if the user exists.
        cursor.close();
        return result;
    }
}
