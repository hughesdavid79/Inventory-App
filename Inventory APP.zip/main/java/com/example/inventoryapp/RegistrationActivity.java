package com.example.inventoryapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Activity to handle user registration in the application.
 */
public class RegistrationActivity extends AppCompatActivity {

    private EditText usernameEditText; // EditText field for entering username.
    private EditText passwordEditText; // EditText field for entering password.
    private EditText confirmPasswordEditText; // EditText field for confirming password.
    private Button registerSubmitButton; // Button to submit the registration form.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        // Initialize UI components.
        usernameEditText = findViewById(R.id.createUser);
        passwordEditText = findViewById(R.id.createPassword);
        confirmPasswordEditText = findViewById(R.id.confirmPassword);
        registerSubmitButton = findViewById(R.id.userCreateButton);

        // Set up click listener for the registration button.
        registerSubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register(); // Call the method to handle user registration.
            }
        });
    }

    /**
     * Handles the registration process.
     */
    private void register() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String confirmPassword = confirmPasswordEditText.getText().toString().trim();

        // Check if the entered passwords match.
        if (!password.equals(confirmPassword)) {
            Toast.makeText(RegistrationActivity.this, "Passwords do not match.", Toast.LENGTH_SHORT).show();
            return; // Stop further processing if the passwords do not match.
        }

        // Save user data using SharedPreferences (not secure for real apps).
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("Username", username);
        editor.putString("Password", password);
        editor.apply();

        // Instantiate the database helper and attempt to add the new user.
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        if (databaseHelper.addUser(username, password)) {
            Toast.makeText(RegistrationActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();

            // Navigate to the main activity on successful registration.
            Intent intent = new Intent(RegistrationActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Close the registration activity.
        } else {
            Toast.makeText(RegistrationActivity.this, "Username already exists", Toast.LENGTH_SHORT).show();
        }
    }
}
